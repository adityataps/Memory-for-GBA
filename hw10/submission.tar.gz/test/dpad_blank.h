/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --transparent=0x000000 dpad_blank dpad_blank.png 
 * Time-stamp: Sunday 11/17/2019, 20:22:28
 * 
 * Image Information
 * -----------------
 * dpad_blank.png 100@100
 * Transparent color: (0, 0, 0)
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DPAD_BLANK_H
#define DPAD_BLANK_H

#define DPAD_BLANK_TRANSPARENT 0x0000

extern const unsigned short dpad_blank[10000];
#define DPAD_BLANK_SIZE 20000
#define DPAD_BLANK_LENGTH 10000
#define DPAD_BLANK_WIDTH 100
#define DPAD_BLANK_HEIGHT 100

#endif

