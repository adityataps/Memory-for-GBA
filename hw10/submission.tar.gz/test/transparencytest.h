/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 transparencytest transparencytest.png 
 * Time-stamp: Sunday 11/17/2019, 20:28:24
 * 
 * Image Information
 * -----------------
 * transparencytest.png 100@100
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef TRANSPARENCYTEST_H
#define TRANSPARENCYTEST_H

extern const unsigned short transparencytest[10000];
#define TRANSPARENCYTEST_SIZE 20000
#define TRANSPARENCYTEST_LENGTH 10000
#define TRANSPARENCYTEST_WIDTH 100
#define TRANSPARENCYTEST_HEIGHT 100

#endif

