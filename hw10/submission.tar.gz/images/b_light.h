/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 b_light b_light.png 
 * Time-stamp: Sunday 11/17/2019, 21:12:27
 * 
 * Image Information
 * -----------------
 * b_light.png 50@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef B_LIGHT_H
#define B_LIGHT_H

extern const unsigned short b_light[2500];
#define B_LIGHT_SIZE 5000
#define B_LIGHT_LENGTH 2500
#define B_LIGHT_WIDTH 50
#define B_LIGHT_HEIGHT 50

#endif

