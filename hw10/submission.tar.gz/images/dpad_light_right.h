/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 dpad_light_right dpad_light_right.png 
 * Time-stamp: Sunday 11/17/2019, 21:13:54
 * 
 * Image Information
 * -----------------
 * dpad_light_right.png 100@100
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DPAD_LIGHT_RIGHT_H
#define DPAD_LIGHT_RIGHT_H

extern const unsigned short dpad_light_right[10000];
#define DPAD_LIGHT_RIGHT_SIZE 20000
#define DPAD_LIGHT_RIGHT_LENGTH 10000
#define DPAD_LIGHT_RIGHT_WIDTH 100
#define DPAD_LIGHT_RIGHT_HEIGHT 100

#endif

