/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 dpad_light_up dpad_light_up.png 
 * Time-stamp: Sunday 11/17/2019, 21:14:03
 * 
 * Image Information
 * -----------------
 * dpad_light_up.png 100@100
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DPAD_LIGHT_UP_H
#define DPAD_LIGHT_UP_H

extern const unsigned short dpad_light_up[10000];
#define DPAD_LIGHT_UP_SIZE 20000
#define DPAD_LIGHT_UP_LENGTH 10000
#define DPAD_LIGHT_UP_WIDTH 100
#define DPAD_LIGHT_UP_HEIGHT 100

#endif

