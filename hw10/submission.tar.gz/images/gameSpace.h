/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 gameSpace gameSpace.png 
 * Time-stamp: Sunday 11/17/2019, 20:39:03
 * 
 * Image Information
 * -----------------
 * gameSpace.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GAMESPACE_H
#define GAMESPACE_H

extern const unsigned short gameSpace[38400];
#define GAMESPACE_SIZE 76800
#define GAMESPACE_LENGTH 38400
#define GAMESPACE_WIDTH 240
#define GAMESPACE_HEIGHT 160

#endif

