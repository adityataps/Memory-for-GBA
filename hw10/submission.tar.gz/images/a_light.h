/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 a_light a_light.png 
 * Time-stamp: Sunday 11/17/2019, 21:12:01
 * 
 * Image Information
 * -----------------
 * a_light.png 50@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef A_LIGHT_H
#define A_LIGHT_H

extern const unsigned short a_light[2500];
#define A_LIGHT_SIZE 5000
#define A_LIGHT_LENGTH 2500
#define A_LIGHT_WIDTH 50
#define A_LIGHT_HEIGHT 50

#endif

