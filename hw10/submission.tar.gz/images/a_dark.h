/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 a_dark a_dark.png 
 * Time-stamp: Sunday 11/17/2019, 21:11:53
 * 
 * Image Information
 * -----------------
 * a_dark.png 50@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef A_DARK_H
#define A_DARK_H

extern const unsigned short a_dark[2500];
#define A_DARK_SIZE 5000
#define A_DARK_LENGTH 2500
#define A_DARK_WIDTH 50
#define A_DARK_HEIGHT 50

#endif

