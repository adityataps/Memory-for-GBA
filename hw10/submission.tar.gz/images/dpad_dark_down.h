/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 dpad_dark_down dpad_dark_down.png 
 * Time-stamp: Sunday 11/17/2019, 22:37:01
 * 
 * Image Information
 * -----------------
 * dpad_dark_down.png 100@100
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DPAD_DARK_DOWN_H
#define DPAD_DARK_DOWN_H

extern const unsigned short dpad_dark_down[10000];
#define DPAD_DARK_DOWN_SIZE 20000
#define DPAD_DARK_DOWN_LENGTH 10000
#define DPAD_DARK_DOWN_WIDTH 100
#define DPAD_DARK_DOWN_HEIGHT 100

#endif

