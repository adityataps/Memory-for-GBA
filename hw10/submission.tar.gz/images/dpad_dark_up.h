/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 dpad_dark_up dpad_dark_up.png 
 * Time-stamp: Sunday 11/17/2019, 22:37:27
 * 
 * Image Information
 * -----------------
 * dpad_dark_up.png 100@100
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef DPAD_DARK_UP_H
#define DPAD_DARK_UP_H

extern const unsigned short dpad_dark_up[10000];
#define DPAD_DARK_UP_SIZE 20000
#define DPAD_DARK_UP_LENGTH 10000
#define DPAD_DARK_UP_WIDTH 100
#define DPAD_DARK_UP_HEIGHT 100

#endif

