/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 b_blank b_blank.png 
 * Time-stamp: Sunday 11/17/2019, 21:12:13
 * 
 * Image Information
 * -----------------
 * b_blank.png 50@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef B_BLANK_H
#define B_BLANK_H

extern const unsigned short b_blank[2500];
#define B_BLANK_SIZE 5000
#define B_BLANK_LENGTH 2500
#define B_BLANK_WIDTH 50
#define B_BLANK_HEIGHT 50

#endif

