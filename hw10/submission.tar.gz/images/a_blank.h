/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 a_blank a_blank.png 
 * Time-stamp: Sunday 11/17/2019, 21:12:06
 * 
 * Image Information
 * -----------------
 * a_blank.png 50@50
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef A_BLANK_H
#define A_BLANK_H

extern const unsigned short a_blank[2500];
#define A_BLANK_SIZE 5000
#define A_BLANK_LENGTH 2500
#define A_BLANK_WIDTH 50
#define A_BLANK_HEIGHT 50

#endif

