/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 LoseScreen LoseScreen.png 
 * Time-stamp: Sunday 11/17/2019, 20:39:17
 * 
 * Image Information
 * -----------------
 * LoseScreen.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSESCREEN_H
#define LOSESCREEN_H

extern const unsigned short LoseScreen[38400];
#define LOSESCREEN_SIZE 76800
#define LOSESCREEN_LENGTH 38400
#define LOSESCREEN_WIDTH 240
#define LOSESCREEN_HEIGHT 160

#endif

